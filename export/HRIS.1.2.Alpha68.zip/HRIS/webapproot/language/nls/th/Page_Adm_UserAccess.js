{
	"cancelButton1": {
		"_classes": {
			"domNode": []
		}
	},
	"deleteButton1": {
		"_classes": {
			"domNode": []
		}
	},
	"descEditor1": {
		"_classes": {
			"domNode": []
		}
	},
	"layoutBox1": {
		"_classes": {
			"domNode": []
		}
	},
	"lms_basic_rolesDetailsPanel": {
		"_classes": {
			"domNode": []
		}
	},
	"lms_basic_rolesDojoGrid": {
		"_classes": {
			"domNode": ["omgDataGrid"]
		},
		"localizationStructure": {
			"desc": "Description",
			"rolecode": "Role Code",
			"roleid": "Role ID",
			"roletitle": "Role Title"
		}
	},
	"lms_basic_rolesGridPanel": {
		"_classes": {
			"domNode": []
		}
	},
	"lms_basic_rolesLiveForm1": {
		"_classes": {
			"domNode": []
		}
	},
	"lms_basic_rolesLiveForm1EditPanel": {
		"_classes": {
			"domNode": []
		}
	},
	"lms_basic_rolesLivePanel1": {
		"_classes": {
			"domNode": []
		}
	},
	"newButton1": {
		"_classes": {
			"domNode": []
		}
	},
	"operationPanel1": {
		"_classes": {
			"domNode": []
		}
	},
	"rolecodeEditor1": {
		"_classes": {
			"domNode": []
		}
	},
	"roleidEditor1": {
		"_classes": {
			"domNode": []
		}
	},
	"roletitleEditor1": {
		"_classes": {
			"domNode": []
		}
	},
	"saveButton1": {
		"_classes": {
			"domNode": []
		}
	},
	"savePanel1": {
		"_classes": {
			"domNode": []
		}
	},
	"updateButton1": {
		"_classes": {
			"domNode": []
		}
	}
}