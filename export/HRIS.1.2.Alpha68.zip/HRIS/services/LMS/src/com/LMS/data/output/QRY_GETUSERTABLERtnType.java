
package com.LMS.data.output;



/**
 * Generated for query "QRY_GETUSERTABLE" on 04/28/2555 00:29:12
 * 
 */
public class QRY_GETUSERTABLERtnType {

    private Long c0;

    public Long getC0() {
        return c0;
    }

    public void setC0(Long c0) {
        this.c0 = c0;
    }

}
