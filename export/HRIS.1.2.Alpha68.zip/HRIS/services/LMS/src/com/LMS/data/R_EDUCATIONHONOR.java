
package com.LMS.data;



/**
 *  LMS.R_EDUCATIONHONOR
 *  07/30/2555 19:20:05
 * 
 */
public class R_EDUCATIONHONOR {

    private Integer EDUCATIONHONORID;
    private String NAME;

    public Integer getEDUCATIONHONORID() {
        return EDUCATIONHONORID;
    }

    public void setEDUCATIONHONORID(Integer EDUCATIONHONORID) {
        this.EDUCATIONHONORID = EDUCATIONHONORID;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

}
