
package com.LMS;



/**
 *  Query names for service "LMS"
 *  07/30/2555 21:16:37
 * 
 */
public class LMSConstants {

    public final static String Q_BasicInfo1QueryName = "Q_BasicInfo1";
    public final static String Q_Chair_GOVQueryName = "Q_Chair_GOV";
    public final static String getDocByIdQueryName = "getDocById";
    public final static String Q_Chair_GOV2QueryName = "Q_Chair_GOV2";

}
