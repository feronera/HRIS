
package com.LMS.data.output;



/**
 * Generated for query "getDocById" on 04/30/2555 18:26:36
 * 
 */
public class GetDocByIdRtnType {

    private Integer c0;

    public Integer getC0() {
        return c0;
    }

    public void setC0(Integer c0) {
        this.c0 = c0;
    }

}
