
package com.LMS.data.output;



/**
 * Generated for query "Q_BasicInfo1" on 07/30/2555 21:01:55
 * 
 */
public class Q_BasicInfo1RtnType {

    private Integer uid;
    private Integer empID;
    private String name;
    private String surname;
    private String personalType;
    private Integer chairID;
    private Integer posID;
    private String unit;
    private String posManage;
    private String posWork;
    private String posLevel;
    private String posType;

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getEmpID() {
        return empID;
    }

    public void setEmpID(Integer empID) {
        this.empID = empID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPersonalType() {
        return personalType;
    }

    public void setPersonalType(String personalType) {
        this.personalType = personalType;
    }

    public Integer getChairID() {
        return chairID;
    }

    public void setChairID(Integer chairID) {
        this.chairID = chairID;
    }

    public Integer getPosID() {
        return posID;
    }

    public void setPosID(Integer posID) {
        this.posID = posID;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getPosManage() {
        return posManage;
    }

    public void setPosManage(String posManage) {
        this.posManage = posManage;
    }

    public String getPosWork() {
        return posWork;
    }

    public void setPosWork(String posWork) {
        this.posWork = posWork;
    }

    public String getPosLevel() {
        return posLevel;
    }

    public void setPosLevel(String posLevel) {
        this.posLevel = posLevel;
    }

    public String getPosType() {
        return posType;
    }

    public void setPosType(String posType) {
        this.posType = posType;
    }

}
