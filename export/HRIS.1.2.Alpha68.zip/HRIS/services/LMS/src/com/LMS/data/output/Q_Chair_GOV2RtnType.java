
package com.LMS.data.output;



/**
 * Generated for query "Q_Chair_GOV2" on 07/30/2555 21:01:55
 * 
 */
public class Q_Chair_GOV2RtnType {

    private Integer uid;
    private String name;
    private String surname;
    private String personalType;
    private Integer c4;

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPersonalType() {
        return personalType;
    }

    public void setPersonalType(String personalType) {
        this.personalType = personalType;
    }

    public Integer getC4() {
        return c4;
    }

    public void setC4(Integer c4) {
        this.c4 = c4;
    }

}
