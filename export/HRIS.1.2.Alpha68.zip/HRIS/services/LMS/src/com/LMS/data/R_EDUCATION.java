
package com.LMS.data;



/**
 *  LMS.R_EDUCATION
 *  07/30/2555 19:20:06
 * 
 */
public class R_EDUCATION {

    private Integer EDUCATIONID;
    private String EDUCATIONCODE;
    private String NAME;
    private String EDUCATIONCODE_EN;
    private String NAME_EN;

    public Integer getEDUCATIONID() {
        return EDUCATIONID;
    }

    public void setEDUCATIONID(Integer EDUCATIONID) {
        this.EDUCATIONID = EDUCATIONID;
    }

    public String getEDUCATIONCODE() {
        return EDUCATIONCODE;
    }

    public void setEDUCATIONCODE(String EDUCATIONCODE) {
        this.EDUCATIONCODE = EDUCATIONCODE;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getEDUCATIONCODE_EN() {
        return EDUCATIONCODE_EN;
    }

    public void setEDUCATIONCODE_EN(String EDUCATIONCODE_EN) {
        this.EDUCATIONCODE_EN = EDUCATIONCODE_EN;
    }

    public String getNAME_EN() {
        return NAME_EN;
    }

    public void setNAME_EN(String NAME_EN) {
        this.NAME_EN = NAME_EN;
    }

}
