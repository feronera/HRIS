
package com.LMS.data;



/**
 *  LMS.R_EDUCATIONSCHOLAR
 *  07/30/2555 19:20:06
 * 
 */
public class R_EDUCATIONSCHOLAR {

    private Integer EDUCATIONSCHOLARID;
    private String NAME;

    public Integer getEDUCATIONSCHOLARID() {
        return EDUCATIONSCHOLARID;
    }

    public void setEDUCATIONSCHOLARID(Integer EDUCATIONSCHOLARID) {
        this.EDUCATIONSCHOLARID = EDUCATIONSCHOLARID;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

}
