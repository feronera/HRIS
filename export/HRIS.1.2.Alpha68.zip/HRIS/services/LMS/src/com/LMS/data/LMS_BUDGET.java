
package com.LMS.data;



/**
 *  LMS.LMS_BUDGET
 *  07/30/2555 19:20:06
 * 
 */
public class LMS_BUDGET {

    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
