
package com.LMS.data;



/**
 *  LMS.LMS_ITS_INTERN
 *  07/30/2555 19:20:06
 * 
 */
public class LMS_ITS_INTERN {

    private Integer LMS_INTERN_ID;
    private Integer CREATEBYID;
    private Integer CREATETS;
    private Integer UPDATEBYID;
    private Integer UPDATETS;
    private Integer MEMO;

    public Integer getLMS_INTERN_ID() {
        return LMS_INTERN_ID;
    }

    public void setLMS_INTERN_ID(Integer LMS_INTERN_ID) {
        this.LMS_INTERN_ID = LMS_INTERN_ID;
    }

    public Integer getCREATEBYID() {
        return CREATEBYID;
    }

    public void setCREATEBYID(Integer CREATEBYID) {
        this.CREATEBYID = CREATEBYID;
    }

    public Integer getCREATETS() {
        return CREATETS;
    }

    public void setCREATETS(Integer CREATETS) {
        this.CREATETS = CREATETS;
    }

    public Integer getUPDATEBYID() {
        return UPDATEBYID;
    }

    public void setUPDATEBYID(Integer UPDATEBYID) {
        this.UPDATEBYID = UPDATEBYID;
    }

    public Integer getUPDATETS() {
        return UPDATETS;
    }

    public void setUPDATETS(Integer UPDATETS) {
        this.UPDATETS = UPDATETS;
    }

    public Integer getMEMO() {
        return MEMO;
    }

    public void setMEMO(Integer MEMO) {
        this.MEMO = MEMO;
    }

}
