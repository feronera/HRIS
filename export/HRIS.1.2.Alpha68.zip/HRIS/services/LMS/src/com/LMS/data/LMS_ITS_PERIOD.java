
package com.LMS.data;



/**
 *  LMS.LMS_ITS_PERIOD
 *  06/26/2555 00:02:02
 * 
 */
public class LMS_ITS_PERIOD {

    private Integer ITS_PERIOD_ID;
    private String INTERN_PERIOD;
    private String DESC;

    public Integer getITS_PERIOD_ID() {
        return ITS_PERIOD_ID;
    }

    public void setITS_PERIOD_ID(Integer ITS_PERIOD_ID) {
        this.ITS_PERIOD_ID = ITS_PERIOD_ID;
    }

    public String getINTERN_PERIOD() {
        return INTERN_PERIOD;
    }

    public void setINTERN_PERIOD(String INTERN_PERIOD) {
        this.INTERN_PERIOD = INTERN_PERIOD;
    }

    public String getDESC() {
        return DESC;
    }

    public void setDESC(String DESC) {
        this.DESC = DESC;
    }

}
